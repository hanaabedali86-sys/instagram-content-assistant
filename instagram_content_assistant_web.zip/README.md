# Instagram Content Assistant (Web Prototype)

A simple Persian Streamlit app for content ideas, caption templates, hashtags, story ideas, and manually entered Instagram metrics.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy for free

1. Upload `app.py`, `requirements.txt`, and `README.md` to a GitHub repository.
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Create an app from that repository and set the main file path to `app.py`.

## Limitations

- Uses rule-based templates, not a connected language model.
- Does not connect to Instagram or fetch account insights automatically.
- Analytics are based only on numbers entered by the user.
- Free hosting limits and availability may change.
