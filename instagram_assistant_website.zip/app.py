import streamlit as st

st.set_page_config(page_title="دستیار محتوای من", page_icon="✨", layout="centered")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"] {font-family:'Vazirmatn',sans-serif;}
.stApp {background:linear-gradient(180deg,#f8f7ff,#fff 48%,#f7f8fc);color:#20243a}
.block-container {max-width:820px;padding-top:1.4rem;padding-bottom:2.5rem}
.hero {background:linear-gradient(135deg,#222642,#51437d);color:white;border-radius:24px;padding:28px 24px;margin-bottom:20px;box-shadow:0 12px 34px #312a581f}
.hero h1 {color:white;font-size:1.9rem;margin:0 0 8px;font-weight:800}
.hero p {color:#e8e7f5;margin:0;line-height:1.9}
.pill {display:inline-block;background:#ffffff20;border:1px solid #ffffff38;padding:5px 12px;border-radius:999px;font-size:.8rem;margin-bottom:12px}
.section-title {font-size:1.12rem;font-weight:700;margin:10px 0 6px}
div[data-testid="stForm"] {background:white;border:1px solid #e8e7f1;border-radius:20px;padding:20px;box-shadow:0 8px 24px #20243a0b}
.stButton button,div[data-testid="stFormSubmitButton"] button {border-radius:12px;font-weight:700;min-height:46px;background:#5d4b91;color:white;border:0;width:100%}
.result-card {background:white;border:1px solid #e8e7f1;border-radius:18px;padding:20px;margin-top:14px;line-height:2}
.small-note {color:#6f7184;font-size:.84rem;line-height:1.8}
#MainMenu,footer {visibility:hidden}
@media(max-width:600px){.block-container{padding:1rem 1rem 2rem}.hero{padding:23px 19px;border-radius:20px}.hero h1{font-size:1.55rem}}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero" dir="rtl">
<div class="pill">✨ ابزار ساده برای سازندگان محتوا</div>
<h1>دستیار محتوای من</h1>
<p>ایده بگیر، کپشن بنویس و برای محتوای اینستاگرامت برنامه‌ریزی کن؛ همه‌چیز در یک جای ساده و مرتب.</p>
</div>
""", unsafe_allow_html=True)
st.markdown('<div class="section-title" dir="rtl">چه محتوایی نیاز داری؟</div>', unsafe_allow_html=True)

with st.form("content_form"):
    c1,c2=st.columns(2)
    with c1: kind=st.selectbox("نوع محتوا",["کپشن پست","ایده ریلز","استوری فروش","برنامه محتوایی هفتگی"])
    with c2: tone=st.selectbox("لحن",["صمیمی و دوستانه","حرفه‌ای","هنری و احساسی","فروش‌محور"])
    topic=st.text_input("موضوع یا محصول",placeholder="مثلاً تابلو کالیگرافی یا توت‌بگ نقاشی‌شده")
    audience=st.text_input("مخاطب هدف (اختیاری)",placeholder="مثلاً علاقه‌مندان هنر و هدیه‌های خاص")
    details=st.text_area("توضیحات بیشتر (اختیاری)",placeholder="چه ویژگی‌ای را می‌خواهی برجسته کنی؟",height=95)
    submit=st.form_submit_button("ساخت پیشنهاد محتوا ✨")

def make_content(kind,topic,audience,details,tone):
    subject=topic.strip() or "محصول یا موضوع پیج شما"
    aud=f" برای {audience.strip()}" if audience.strip() else ""
    extra=f"\n\nنکته‌ای که می‌خواهیم برجسته کنیم: {details.strip()}" if details.strip() else ""
    if kind=="کپشن پست":
        return f"✨ یک جزئیات کوچک می‌تواند حال‌وهوای یک فضا را عوض کند.\n\n{subject} با عشق و توجه به جزئیات آماده شده تا انتخابی متفاوت{aud} باشد.{extra}\n\nبرای اطلاعات بیشتر یا سفارش، در دایرکت پیام بده 💌\n\n#هنر #دستساز #ایده_هدیه #هنر_ایرانی"
    if kind=="ایده ریلز":
        return f"🎬 ایده ریلز برای «{subject}»\n\n۱. شروع: نمای نزدیک و جذاب از جزئیات کار.\n۲. میانه: چند ثانیه از مراحل ساخت.\n۳. پایان: نمایش کامل محصول در نور طبیعی.\n۴. متن روی ویدئو: «وقتی هنر به جزئیات زندگی اضافه می‌شود ✨»\n۵. دعوت: «برای دیدن جزئیات و سفارش، پیام بده.»\n\nلحن پیشنهادی: {tone}.{extra}"
    if kind=="استوری فروش":
        return f"📲 سناریوی ۳ استوری برای «{subject}»\n\nاستوری ۱: «دنبال یک انتخاب خاص و متفاوتی؟ ✨»\n\nاستوری ۲: «این {subject} با توجه به جزئیات آماده شده است.»{extra}\n\nاستوری ۳: «برای قیمت و سفارش، همین حالا دایرکت بده 💌»\n\nایده تعامل: در استوری اول نظرسنجی «ساده یا هنری؟» بگذار."
    return f"🗓️ برنامه هفتگی برای «{subject}»\n\nشنبه: معرفی محصول یا موضوع هفته\nیکشنبه: پشت‌صحنه ساخت\nدوشنبه: ریلز کوتاه با شروع جذاب\nسه‌شنبه: پرسش و پاسخ در استوری\nچهارشنبه: نمایش جزئیات و مزایا\nپنجشنبه: پاسخ به پرسش پرتکرار\nجمعه: معرفی محصول همراه دعوت به سفارش\n\nنکته: بازدید، ذخیره، پاسخ استوری و پیام‌ها را بررسی کن."

if submit:
    if not topic.strip(): st.warning("لطفاً موضوع یا محصول را وارد کن.")
    else:
        result=make_content(kind,topic,audience,details,tone)
        st.markdown('<div class="section-title" dir="rtl">پیشنهاد آماده تو</div>',unsafe_allow_html=True)
        st.markdown('<div class="result-card" dir="rtl">'+result.replace("\n","<br>")+'</div>',unsafe_allow_html=True)
        st.download_button("دریافت متن به‌صورت فایل TXT",result,file_name="content-suggestion.txt",mime="text/plain",use_container_width=True)

st.markdown("---")
st.markdown('<div class="small-note" dir="rtl"><b>نسخه اولیه</b><br>این نسخه با قواعد ساده پایتون پیشنهاد محتوا تولید می‌کند و هنوز به مدل هوش مصنوعی یا حساب اینستاگرام متصل نیست. برای گفت‌وگوی هوشمندتر، بعداً می‌توانیم API مناسب را اضافه کنیم.</div>',unsafe_allow_html=True)
