# دستیار محتوای من

نسخه اولیه فارسی و سازگار با موبایل، ساخته‌شده با Streamlit.

## اجرای محلی
```bash
pip install -r requirements.txt
streamlit run app.py
```

## تنظیم Render
- Build Command: `pip install -r requirements.txt`
- Start Command: `streamlit run app.py --server.address 0.0.0.0 --server.port $PORT`

این نسخه با قواعد ساده پایتون محتوا تولید می‌کند و هنوز به API هوش مصنوعی یا اینستاگرام متصل نیست. پلن رایگان میزبان ممکن است هنگام بی‌استفاده‌ماندن سرویس را متوقف کند.
